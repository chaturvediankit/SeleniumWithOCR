package Utility;


import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelFileUtil {
	
	public static String getXLSData(String strExcelFilePath, String strSheetName, int iRowNumber, int iColumn) {
		String strData = "";
		try {
			HSSFWorkbook myExcelBook = new HSSFWorkbook(new FileInputStream(strExcelFilePath));
			HSSFSheet myExcelSheet = myExcelBook.getSheet(strSheetName);
			strData = String.valueOf(myExcelSheet.getRow(iRowNumber).getCell(iColumn));
			return strData;

		} catch (Exception e) {
			return strData;
		}

	}

	// This will read the row count from from .xls files
	public static int getXLSRowCount(String strExcelFilePath, String strSheetName) {
		int iRowcount = 0;
		try {
			HSSFWorkbook myExcelBook = new HSSFWorkbook(new FileInputStream(strExcelFilePath));
			HSSFSheet myExcelSheet = myExcelBook.getSheet(strSheetName);

			iRowcount = myExcelSheet.getLastRowNum();

			return iRowcount;

		} catch (Exception e) {
			return iRowcount;
		}

	}

	// This will read the column count from from .xls files
	public static int getXLSColCount(String strExcelFilePath, String strSheetName) {
		int iColcount = 0;
		try {
			HSSFWorkbook myExcelBook = new HSSFWorkbook(new FileInputStream(strExcelFilePath));
			HSSFSheet myExcelSheet = myExcelBook.getSheet(strSheetName);
			iColcount = myExcelSheet.getRow(0).getLastCellNum();
			return iColcount;

		} catch (Exception e) {
			return iColcount;
		}

	}

	// This will read data from .xlsx,s.xlsm, files
	public static String getXLSXData(String strExcelFilePath, String strSheetName, int iRowNumber, int iColumn) {
		String strData = "";
		try {
			FileInputStream inputStream = new FileInputStream(new File(strExcelFilePath));
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet myExcelSheet = workbook.getSheet(strSheetName);
			strData = String.valueOf(myExcelSheet.getRow(iRowNumber).getCell(iColumn));
			return strData;

		} catch (Exception e) {
			return strData;
		}

	}

	// This will read the row count from from .xls files
	public static int getXLSXRowCount(String strExcelFilePath, String strSheetName) {
		int iRowcount = 0;
		try {
			FileInputStream inputStream = new FileInputStream(new File(strExcelFilePath));
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet myExcelSheet = workbook.getSheet(strSheetName);
			iRowcount = myExcelSheet.getLastRowNum();

			return iRowcount;

		} catch (Exception e) {
			return iRowcount;
		}

	}

	// This will read the column count from from .xls files
	public static int getXLSXColCount(String strExcelFilePath, String strSheetName) {
		int iColcount = 0;
		try {
			FileInputStream inputStream = new FileInputStream(new File(strExcelFilePath));
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet myExcelSheet = workbook.getSheet(strSheetName);
			iColcount = myExcelSheet.getRow(0).getLastCellNum();
			return iColcount;

		} catch (Exception e) {
			return iColcount;
		}

	}

	// This will write data to .xlsx,.xlsm, files
	public void setXLSXData(String strExcelFilePath, String strSheetName, int iRowNumber, int iColumn,
			String strValue) throws IOException {
		FileInputStream inputStream = new FileInputStream(new File(strExcelFilePath));
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		XSSFSheet myExcelSheet = workbook.getSheet(strSheetName);
		XSSFCell Cell;
		XSSFRow Row;
	    try {

			Row = myExcelSheet.getRow(iRowNumber);

			Cell = Row.getCell(iColumn, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);

			if (Cell == null) {

				Cell = Row.createCell(iColumn);

				Cell.setCellValue(strValue);

			} else {

				Cell.setCellValue(strValue);

			}

			workbook.write(new FileOutputStream(strExcelFilePath));
		} catch (Exception e) {
			return;
		}

	}
	
	public static void openExcel() throws IOException{
	Desktop dk = null;
	dk = Desktop.getDesktop();
	dk.open(new File("Test.xlsm"));
	}

}
