package Utility;

public class GlobalContstants {

	 //List of Data Sheet Column Numbers
	 public static final int Col_AppName = 0; 
	 public static final int Col_AppEnv=1 ;
	 public static final int Col_RunFlag =3 ;
	 public static final int Col_URL =4;
	 public static final int Col_Object =5;
	 public static final int Col_Status =6;
	 public static final int Col_TimeStamp =7;
}
