package Utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class CoreFunctions {
	

	public String GetCurrentDateTime(){
		DateFormat dateTimeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String CurrentDate = dateTimeFormat.format(date); 
		return CurrentDate; 
	}

	  public boolean IsElementPresent(WebDriver driver, String locator)
       {
           boolean Present = false;
           try
           {
                if (driver.findElement(By.xpath(locator)).isDisplayed())
               {
                   Present = true;
                   System.out.println("Element Is Seen");
               }
               return Present;
           }catch (Exception E)
           {
               System.out.println("No Such Element : {0}");
               return Present;
           }
	
       }
}
