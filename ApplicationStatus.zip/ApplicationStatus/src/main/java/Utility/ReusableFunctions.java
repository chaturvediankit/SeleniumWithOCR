package Utility;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class ReusableFunctions {
	WebDriver driver;
	
	//@To setup browser
	public WebDriver setup() throws InterruptedException, IOException{
	    String browserType =pReader("browser");
		if(browserType.contains("Chrome")){ 
			launchChromeBrowser();		
		    }
		else if (browserType.contains("InternetExplorer")) {
			launchIEBrowser();
			}
		else{
			System.out.println("Browser is not supported so will launch application In chrome");
			launchChromeBrowser();	
			}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//System.out.println("Application url opened");	    
		return driver;
		}
	// To launch Chrome Browser
	 void launchIEBrowser(){
		    System.setProperty("webdriver.ie.driver","IEDriverServer3.exe");
			//InternetExplorerOptions options = new InternetExplorerOptions();
			//options.introduceFlakinessByIgnoringSecurityDomains();
			//options.requireWindowFocus();
			driver = new InternetExplorerDriver(); 
	 }
	
	// To launch Chrome Browser
	 void launchChromeBrowser(){
		 System.setProperty("webdriver.chrome.driver","chromedriver1.exe");
		 ChromeOptions options = new ChromeOptions();
		 options.addArguments("disable-extensions");
		 options.setExperimentalOption("useAutomationExtension", false);
		 driver = new ChromeDriver(options);
	 }
	//To read property file
	 public String pReader(String property) throws IOException{
		FileReader reader=new FileReader("resources/login.properties");
		Properties p=new Properties();
		p.load(reader);
		String value=p.getProperty(property);
		System.out.println(value);
		 return value;
		 	}
	 //To create New Html File
	 public PrintWriter createHtmlFile(String filePath) throws IOException {
		 
		 PrintWriter pw = new PrintWriter(new FileWriter(filePath));
		 pw.println("<head><title>ADM Application Status</title>"+
	        		"<style type=\'text/css\'>" + 
	        		"table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}" + 
	        		"td,th {border:1px solid #009;padding:.25em .5em}" + 
	        		".passedodd td {background-color: #0A0}" +
	        		".failedodd td,.numi_attn {background-color:#FF0000}" + 
	        		"</style></head>" + 
	        		"<body><b>Application Status</b>" + 
	        		"<table cellspacing='0' cellpadding='0' class='testOverview'>" + 
	        		"<tr><th>S.N.</th><th>AppName</th><th>AppEnvironment</th><th>AppURL</th><th>Status</th><th>Time</th></tr>"
	        		);
		return pw;
		 
	 }
	 //To create html row for passed and failed test case
	 public void writeHtmlFile(PrintWriter pw,int rowCounter, String app,String env, String Url,String status,String timeStamp ) {
		pw.println("<tr class='"+status.toLowerCase()+"odd'><td rowspan='1'>"+rowCounter+"</td><td rowspan='1'>"+app+"</td><td rowspan='1'>"+env+"</td><td><a href='#m0'>"+Url+"</a></td><td rowspan='1'>"+ status+"</td><td rowspan='1'>"+timeStamp+"</td></tr>");
		 
	 }
	 // Close table and html file
	 public void closeHtmlFile(PrintWriter pw) {
		 pw.println("</table>");
	     pw.close();
		 
	 }
	 //Read html file
	 public String readHtmlFile(String filePath) {
    	  StringBuilder contentBuilder = new StringBuilder();
	    	  try {
	    	      BufferedReader in = new BufferedReader(new FileReader(filePath));
	    	      String str;
	    	      while ((str = in.readLine()) != null) {
	    	          contentBuilder.append(str);
	    	      }
	    	      in.close();
	    	  } catch (IOException e) {
	    	  }
	      String Htmlcontent = contentBuilder.toString();
	      //Htmlcontent= Htmlcontent.split("<h1>Test</h1>")[0]+"</body></html>";
	 	return Htmlcontent;
		 
	 }
	//Robot framework to upload file
	public void uploadFile(String fileName) throws AWTException{
		StringSelection ss = new StringSelection(fileName);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}
}
