package Script;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utility.CoreFunctions;
import Utility.ExcelFileUtil;
import Utility.ReusableFunctions;
import net.sourceforge.lept4j.util.LoadLibs;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;


public class OCR {

	
	public static	WebDriver driver;
	static ReusableFunctions rf=new ReusableFunctions();
	ExcelFileUtil excelUtil=new ExcelFileUtil();
	CoreFunctions cf=new CoreFunctions();
	
	
	public static void main(String [] args) throws InterruptedException, IOException, TesseractException {
		driver=rf.setup();
		
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys("ankit.chaturvedi@kpmg.co.uk");
        driver.findElement(By.xpath("//input[@value='Next']")).click();
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//td[text()='Testentity_new']")).click();
        Thread.sleep(5000);


        driver.findElement(By.cssSelector("#extract-btn")).click();
        Thread.sleep(5000);

        driver.findElement(By.xpath("//button[text()='Yes']")).click();
        Thread.sleep(9000);
        Thread.sleep(9000);
        System.out.println("Testtt");
        Thread.sleep(9000);
		
        //File test1=driver.findElement(By.xpath("//img[@class='unselectable']")).getScreenshotAs(OutputType.FILE);
        String path=System.getProperty("user.dir")+"/test.png";
       // FileHandler.copy(test1,new File(path));
        ITesseract tesseract=new Tesseract();
        File tessDataFolder = LoadLibs.extractNativeResources("tessdata"); 
		tesseract.setDatapath(tessDataFolder.getPath());
		tesseract.setLanguage("eng");
		System.out.println(tesseract.doOCR(new File("active.png")));
        }
        
	
}
