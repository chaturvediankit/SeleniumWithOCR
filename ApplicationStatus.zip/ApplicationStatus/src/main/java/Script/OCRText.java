package Script;

import java.io.File;

import net.sourceforge.lept4j.util.LoadLibs;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;



public class OCRText {	

	public static void main(String[] args) throws TesseractException{
        
		ITesseract tesseract = new Tesseract();
		File tessDataFolder = LoadLibs.extractNativeResources("tessdata"); 
		tesseract.setDatapath(tessDataFolder.getPath());
		tesseract.setLanguage("eng");
		System.out.println(tesseract.doOCR(new File("active.png")));
	}	

}
